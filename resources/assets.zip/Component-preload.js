//@ui5-bundle servicesdesk/Component-preload.js
sap.ui.require.preload({
	"servicesdesk/manifest.json":'{"_version":"1.49.0","sap.app":{"id":"servicesdesk","applicationVersion":{"version":"1.0.0"},"type":"application","title":"","description":"servicesdesk","i18n":"i18n/i18n.properties","crossNavigation":{"inbounds":{"servicesdesk.tipossolicitud-display":{"semanticObject":"servicesdesk.tipossolicitud","action":"display","signature":{"parameters":{},"additionalParameters":"allowed"}}}}},"sap.cloud":{"public":true,"service":"servicesdesk.service"}}'
});
//# sourceMappingURL=Component-preload.js.map
